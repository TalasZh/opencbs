CREATE PROCEDURE dbo.Rep_Disbursements
	@start_date DATETIME
	, @end_date DATETIME
	, @disbursed_in INT
	, @display_in INT
	, @user_id INT
	, @subordinate_id INT
	, @branch_id INT
AS BEGIN
	DECLARE @conso_mode BIT
	SELECT @conso_mode = CAST(value AS BIT)
	FROM dbo.GeneralParameters
	WHERE [key] = 'CONSOLIDATION_MODE'

	IF 0 = @conso_mode
	BEGIN
		SELECT Cont.contract_code, Dts.name AS [district], Pack.name AS [loan_product],
		ISNULL(Gr.name, ISNULL(Pers.first_name, '') + SPACE(1) + ISNULL(Pers.last_name, '')) AS [client_name], Trs.loan_cycle,
		Us.first_name + SPACE(1) + Us.last_name AS [loan_officer], Br.code AS branch_name, Dis.disbursement_date, Dis.amount, Dis.interest, Dis.fees  
		FROM dbo.Disbursements_MC(@start_date, @end_date, @disbursed_in, @display_in, @user_id, @subordinate_id, @branch_id) AS Dis
		LEFT JOIN dbo.Credit AS Cr ON Cr.id = Dis.contract_id
		LEFT JOIN dbo.Contracts AS Cont ON Dis.contract_id = Cont.id
		LEFT JOIN dbo.Projects AS Pr ON Cont.project_id = Pr.id
		LEFT JOIN dbo.Groups AS Gr ON Gr.id = Pr.tiers_id
		LEFT JOIN dbo.Persons AS Pers ON Pers.id = Pr.tiers_id
		LEFT JOIN dbo.Tiers AS Trs ON Pr.tiers_id = Trs.id
		LEFT JOIN dbo.Branches Br ON Br.id = Trs.branch_id
		LEFT JOIN dbo.Districts AS Dts ON Dts.id = Trs.district_id
		LEFT JOIN dbo.Users AS Us ON Cr.loanofficer_id = Us.id
		LEFT JOIN dbo.Packages AS Pack ON Cr.package_id = Pack.id
		WHERE Dis.disbursement_date BETWEEN @start_date AND @end_date
		AND Dis.disbursed = 1
	END
	ELSE
	BEGIN
		DECLARE @pivot INT
		SELECT @pivot = id
		FROM dbo.Currencies
		WHERE is_pivot = 1

		SELECT t.contract_code
			, t.district
			, t.loan_product
			, t.client_name
			, t.loan_cycle
			, t.loan_officer
			, t.branch_name
			, t.disbursement_date
			, t.amount * dbo.GetXR(@pivot, @display_in, t.disbursement_date) amount
			, t.interest * dbo.GetXR(@pivot, @display_in, t.disbursement_date) interest
			, t.fees * dbo.GetXR(@pivot, @display_in, t.disbursement_date) fees
		FROM dbo.Rep_Disbursements_Data t
		LEFT JOIN
		(
			SELECT branch_name
				, ROW_NUMBER() OVER (ORDER BY branch_name) branch_id
			FROM dbo.Rep_Disbursements_Data
			GROUP BY branch_name
		) b ON b.branch_name = t.branch_name
		WHERE t.load_date BETWEEN @start_date AND @end_date
		AND (0 = @branch_id OR b.branch_id = @branch_id)
	END
END
