CREATE PROCEDURE [dbo].[Rep_Loan_Renewal_Help]
	@incrementNumber INT
	, @startDate DATETIME
    , @branch_id INT
AS BEGIN

DECLARE @al TABLE
(
	id INT NOT NULL
	, olb MONEY NOT NULL
	, late_days INT NOT NULL
)
INSERT INTO @al
SELECT id, olb, late_days
FROM dbo.ActiveLoans(@startDate, @branch_id)

SELECT DISTINCT ISNULL(p.last_name + ' ' + p.first_name,p2.last_name + ' ' + p2.first_name) AS client_name,
(CASE 
	WHEN (ti.secondary_home_phone IS NOT NULL AND LTRIM(RTRIM(ti.secondary_home_phone))!='')
	     AND
		(ti.secondary_personal_phone IS NOT NULL AND LTRIM(RTRIM(ti.secondary_personal_phone))!='')
	THEN ti.secondary_home_phone+', '+ti.secondary_personal_phone
	ELSE 
		CASE WHEN (ti.secondary_home_phone IS NOT NULL AND LTRIM(RTRIM(ti.secondary_home_phone))!='')
			 THEN ti.secondary_home_phone
		ELSE CASE WHEN (ti.secondary_personal_phone IS NOT NULL AND LTRIM(RTRIM(ti.secondary_personal_phone))!='')
			 THEN ti.secondary_personal_phone
			 ELSE		
			 CASE WHEN (ti.home_phone IS NOT NULL AND LTRIM(RTRIM(ti.home_phone))!='')
						AND
						(ti.personal_phone IS NOT NULL AND LTRIM(RTRIM(ti.personal_phone))!='')
						THEN ti.home_phone +', '+ti.personal_phone
				ELSE
					CASE WHEN (ti.home_phone IS NOT NULL AND LTRIM(RTRIM(ti.home_phone))!='') THEN
					ti.home_phone 
					ELSE
						CASE WHEN (ti.personal_phone IS NOT NULL AND LTRIM(RTRIM(ti.personal_phone))!='') THEN
							ti.personal_phone
						END
					END
				END
			END
		END
	END) AS phone_number,
d.name AS district_name,
u.last_name + ' ' + u.first_name AS loan_officer,
co.close_date,
cr.Amount,
pkg.code,
co.contract_code,
DATEDIFF(dd, GETDATE(),co.close_date) AS days_before_close,
al.olb,
al.late_days,
ti.client_type_code
FROM dbo.Contracts co
INNER JOIN dbo.Credit cr ON co.id=cr.id 
INNER JOIN dbo.Packages pkg ON pkg.id=cr.package_id 
INNER JOIN dbo.Projects pr ON co.project_id = pr.id
INNER JOIN dbo.Users u ON cr.loanofficer_id = u.id 
INNER JOIN dbo.Tiers ti ON ti.id = pr.tiers_id
INNER JOIN dbo.Districts d ON ti.district_id = d.id 
INNER JOIN (SELECT Installments.contract_id,
					SUM (
						  CASE WHEN Installments.expected_date IS NULL AND Installments.paid_date IS NULL THEN 0
						  ELSE
							  CASE WHEN  Installments.paid_date IS NULL THEN 
									CASE WHEN DATEDIFF(dd, Installments.expected_date, GETDATE())<0 THEN 0
										 ELSE DATEDIFF(dd, Installments.expected_date, GETDATE()) 
										 END
									ELSE CASE WHEN DATEDIFF(dd, Installments.expected_date, paid_date)<0 THEN 0 
										 ELSE DATEDIFF(dd, Installments.expected_date, paid_date)
										 END
									END
							  END
						) AS total_late_days
				FROM      dbo.Installments
				GROUP BY Installments.contract_id
				) AS Ins ON co.id= Ins.contract_id
INNER JOIN @al al ON co.id = al.id
LEFT JOIN dbo.Persons p ON p.id = ti.id 
LEFT JOIN dbo.LoanShareAmounts lsa ON ti.id= lsa.group_id AND lsa.contract_id = co.id
LEFT JOIN dbo.Persons p2 ON p2.id= lsa.person_id
					   
WHERE co.closed=0 AND (co.close_date BETWEEN @startDate AND DATEADD(dd, @incrementNumber, @startDate)) AND ti.branch_id = @branch_id
ORDER BY days_before_close
END