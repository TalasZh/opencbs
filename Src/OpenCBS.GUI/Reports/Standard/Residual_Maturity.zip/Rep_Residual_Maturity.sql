CREATE PROCEDURE [dbo].[Rep_Residual_Maturity]
@date DATETIME, @disbursed_in INT, @display_in INT, @branch_id INT
AS 
BEGIN
	DECLARE @m1 DATETIME
	DECLARE @m2 DATETIME
	DECLARE @m3 DATETIME
	DECLARE @m6 DATETIME
	DECLARE @m12 DATETIME
	DECLARE @y2 DATETIME
	DECLARE @y3 DATETIME
	SET @m1 = DATEADD(MM, 1, @date)
	SET @m2 = DATEADD(MM, 2, @date)
	SET @m3 = DATEADD(MM, 3, @date)
	SET @m6 = DATEADD(MM, 6, @date)
	SET @m12 = DATEADD(MM, 12, @date)
	SET @y2 = DATEADD(YY, 2, @date)
	SET @y3 = DATEADD(YY, 3, @date)
    DECLARE @to DATETIME
    SET @to = DATEADD(YY, 10, @date)

	SELECT
	(SELECT SUM(principal) FROM dbo.LateAmounts_MC(@date, @disbursed_in, @display_in, 0, 0, @branch_id)) AS p_late
	, SUM(CASE WHEN i.d >= @date AND i.d < @m1 THEN i.p ELSE 0 END) AS p_1m
	, SUM(CASE WHEN i.d >= @m1 AND i.d < @m2 THEN i.p ELSE 0 END) AS p_2m
	, SUM(CASE WHEN i.d >= @m2 AND i.d < @m3 THEN i.p ELSE 0 END) AS p_3m
	, SUM(CASE WHEN i.d >= @m3 AND i.d < @m6 THEN i.p ELSE 0 END) AS p_4_6m
	, SUM(CASE WHEN i.d >= @m6 AND i.d < @m12 THEN i.p ELSE 0 END) AS p_6_12m
	, SUM(CASE WHEN i.d >= @m12 AND i.d < @y2 THEN i.p ELSE 0 END) AS p_1_2y
	, SUM(CASE WHEN i.d >= @y2 AND i.d < @y3 THEN i.p ELSE 0 END) AS p_2_3y
	, SUM(CASE WHEN i.d >= @y3 THEN i.p ELSE 0 END) AS p_3y
	, (SELECT SUM(interest) FROM dbo.LateAmounts_MC(@date, @disbursed_in, @display_in, 0, 0, @branch_id)) AS i_late
	, SUM(CASE WHEN i.d >= @date AND i.d < @m1 THEN i.i ELSE 0 END) AS i_1m
	, SUM(CASE WHEN i.d >= @m1 AND i.d < @m2 THEN i.i ELSE 0 END) AS i_2m
	, SUM(CASE WHEN i.d >= @m2 AND i.d < @m3 THEN i.i ELSE 0 END) AS i_3m
	, SUM(CASE WHEN i.d >= @m3 AND i.d < @m6 THEN i.i ELSE 0 END) AS i_4_6m
	, SUM(CASE WHEN i.d >= @m6 AND i.d < @m12 THEN i.i ELSE 0 END) AS i_6_12m
	, SUM(CASE WHEN i.d >= @m12 AND i.d < @y2 THEN i.i ELSE 0 END) AS i_1_2y
	, SUM(CASE WHEN i.d >= @y2 AND i.d < @y3 THEN i.i ELSE 0 END) AS i_2_3y
	, SUM(CASE WHEN i.d >= @y3 THEN i.i ELSE 0 END) AS i_3y
	FROM (
		SELECT contract_id
		, expected_date AS d
		, principal - prepaid_principal AS p
		, interest - prepaid_interest AS i
		FROM dbo.ExpectedInstallments_MC(@date, @to, @disbursed_in, @display_in, 0, 0, @branch_id)
	) AS i
END
