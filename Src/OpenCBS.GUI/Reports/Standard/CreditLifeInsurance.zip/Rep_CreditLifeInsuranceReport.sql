CREATE PROCEDURE [dbo].[Rep_CreditLifeInsuranceReport] 
@date_from DATETIME
,@date_to DATETIME 
,@branch_id INT
,@disbursed_in INT
,@display_in INT
AS 
BEGIN
	SELECT DISTINCT 
			cr.id,
			COALESCE(pe.first_name+pe.last_name+pe.father_name,
					 pe.first_name+pe.last_name,
					 gr.name,
					 corp.name) AS beneficiary_name,
			cr.amount*dbo.GetXR(pkg.currency_id, @display_in, d.disbursement_date) as principal_amount,
			co.contract_code AS contract_code,
			d.disbursement_date,
			ISNULL(collected_premium,0)*dbo.GetXR(pkg.currency_id, @display_in, InitialPremiumCollected.[event_date])  AS collected_premium,
			earned_premium *dbo.GetXR(pkg.currency_id, @display_in, Premiums.[event_date]) AS earned_premium ,
			premium_to_refund*dbo.GetXR(pkg.currency_id, @display_in, Premiums.[event_date]) AS premium_to_refund,
			pe.[identification_data] as client_code
FROM    Contracts co 
			INNER JOIN Disbursements_MC(@date_from, @date_to, @disbursed_in, @display_in, 0, 0, @branch_id) AS d ON co.id=d.contract_id
			INNER JOIN Projects pr ON co.project_id = pr.id
			INNER JOIN Tiers ti ON pr.tiers_id = ti.id
			INNER JOIN Credit cr ON co.id = cr.id
			INNER JOIN Packages AS pkg ON cr.package_id=pkg.id
			INNER JOIN Users u ON cr.loanofficer_id = u.id
			LEFT JOIN 
			(
				SELECT ContractEvents.contract_id, 
					   CIE.commission AS collected_premium,
					   ContractEvents.[event_date]
				FROM ContractEvents
				INNER JOIN [dbo].[CreditInsuranceEvents] AS CIE ON CIE.id = ContractEvents.id
				WHERE ContractEvents.is_deleted=0 AND ContractEvents.event_type='LCIE'
			
			) AS InitialPremiumCollected 	 ON InitialPremiumCollected.contract_id= co.id
			
			LEFT JOIN 
			(
				SELECT ContractEvents.contract_id
				,CIE.commission AS earned_premium
				,CIE.principal AS premium_to_refund
				,ContractEvents.[event_date]
				FROM ContractEvents
				INNER JOIN [dbo].[CreditInsuranceEvents] AS CIE ON CIE.id = ContractEvents.id
				WHERE ContractEvents.is_deleted=0 AND (ContractEvents.event_type='LCIP' OR ContractEvents.event_type='LCIW')
			
			) AS Premiums 	 ON Premiums.contract_id= co.id
			
			INNER JOIN ContractEvents ce ON ce.contract_id = co.id
			INNER JOIN LoanDisbursmentEvents lde ON lde.id = ce.id
			LEFT JOIN Persons pe ON pe.id = ti.id
			LEFT JOIN Groups gr ON gr.id = ti.id
			LEFT JOIN Corporates corp ON corp.id = ti.id
			WHERE collected_premium>0
			ORDER BY d.disbursement_date, cr.id
END		
