CREATE PROCEDURE dbo.Rep_Guarantors
	@startDate DATE,
	@endDate DATE,	
	@disbursed_in INT,
	@display_in INT,
	@branch_id INT,
	@user_id INT,
	@subordinate_id INT
AS
BEGIN
	--DECLARE @endDate         DATE = GETDATE(),
	--        @startDate       Date = DATEADD(dd, -20, GETDATE()),
	--        @disbursed_in    INT = 0,
	--        @display_in      INT = 1,
	--        @branch_id       INT = 0,
	--        @user_id         INT = 1,
	--        @subordinate_id  INT = 0                       	

	DECLARE @users           TABLE
			(id INT NOT NULL)
		
	INSERT INTO @users
	SELECT @user_id

	INSERT INTO @users
	SELECT subordinate_id
	FROM   dbo.UsersSubordinates
	WHERE  USER_ID = @user_id
		
	SELECT c.contract_code,
		   client.[name] client_name,
		   u.first_name + ' ' + u.last_name loan_officer,
		   p.code package_code,
		   d.[name] district_name,
		   ISNULL(alm.olb, 0) olb,
		   cr.amount loan_amount,
		   guarantor.[name] guarantor_name,
		   ps.identification_data,
		   gs.guarantee_amount
	FROM   Guarantors() gs
		   INNER JOIN ContractEvents ce
				ON  gs.contract_id = ce.contract_id
				AND ce.event_type = N'LODE'
				AND ce.event_date >= @startDate
				AND ce.event_date < DATEADD(dd, 1, @endDate)
		   INNER JOIN Contracts c
				ON  gs.contract_id = c.id
		   INNER JOIN dbo.Credit cr
				ON  cr.id = c.id
		   INNER JOIN Users u
				ON  cr.loanofficer_id = u.id
				AND (
						0 = @subordinate_id
						AND cr.loanofficer_id IN (SELECT id
												  FROM   @users)
						OR cr.loanofficer_id = @subordinate_id
					)
		   INNER JOIN dbo.Packages p
				ON  cr.package_id = p.id
		   LEFT JOIN dbo.ActiveLoans_MC(@endDate, @disbursed_in, @display_in, 0) 
				alm
				ON  cr.id = alm.id
		   INNER JOIN dbo.Projects pr
				ON  c.project_id = pr.id
		   INNER JOIN Clients client
				ON  pr.tiers_id = client.id
		   INNER JOIN dbo.Tiers tr
				ON  tr.id = pr.tiers_id
				AND (@branch_id = 0 OR tr.branch_id = @branch_id)
		   LEFT JOIN dbo.Districts d
				ON  tr.district_id = d.id
		   INNER JOIN Clients guarantor
				ON  gs.tiers_id = guarantor.id
		   INNER JOIN Persons ps
				ON  guarantor.id = ps.id
END