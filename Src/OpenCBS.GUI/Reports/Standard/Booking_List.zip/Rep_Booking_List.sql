CREATE PROCEDURE [dbo].[Rep_Booking_List]
	@from DATETIME,
	@to DATETIME,
	@disbursed_in INT,
	@display_in INT,
	@account_id INT,
	@branch_id INT
AS
BEGIN
	DECLARE @day_before DATETIME
	SET @day_before = DATEADD(DAY, -1, @from)
	;
	
	WITH _coa AS
	(
	    SELECT id,
	           account_number,
	           label,
	           debit_plus
	    FROM   dbo.ChartOfAccounts
	    WHERE  rgt = lft + 1 -- leaf accounts only
	    AND (@account_id = 0 OR id = @account_id)
	)
	
	SELECT _coa.id account_id,
	       _coa.account_number,
	       _coa.label account_label,
	       _coa.debit_plus,
	       mov.transaction_id,
	       CASE WHEN mov.contract_type = 0 THEN cl.[name] ELSE scl.[name] END client_name,
	       mov.transaction_date,
	       tb.balance opening_balance,
	       mov.debit,
	       mov.credit,
	       CASE
			WHEN mov.event_id IS NULL THEN
				mov.comment				
			ELSE
				CASE
					WHEN mov.contract_type = 0 THEN
						ISNULL(ce.event_type + SPACE(1), '') + ISNULL(c.contract_code + SPACE(1), '') + CAST(ce.id AS NVARCHAR) + SPACE(1) + ISNULL(mov.comment, '')
					ELSE
						ISNULL(se.code + SPACE(1), '') + ISNULL(sc.code + SPACE(1), '') + CAST(se.id AS NVARCHAR) + SPACE(1) + ISNULL(mov.comment, '')
				END
		   END comment
	FROM   _coa
	       INNER JOIN dbo.Movements(@from, @to, @disbursed_in, @display_in, 0, @branch_id, 7) 
	            mov
	            ON  mov.account_id = _coa.id
	       INNER JOIN dbo.TrialBalance(@day_before, @disbursed_in, @display_in, 0, @branch_id, 7) 
	            tb
	            ON  tb.account_id = _coa.id
	       LEFT JOIN dbo.Contracts c
	            ON  mov.contract_type = 0 AND c.id = mov.contract_id
	       LEFT JOIN dbo.Projects j
	            ON  j.id = c.project_id
	       LEFT JOIN dbo.Clients cl
	            ON  cl.id = j.tiers_id
	       LEFT JOIN ContractEvents ce ON mov.contract_type = 0 AND mov.event_id = ce.id
	       LEFT JOIN SavingContracts sc ON mov.contract_type = 1 AND mov.contract_id = sc.id
	       LEFT JOIN SavingEvents se ON mov.contract_type = 1 AND mov.event_id = se.id
	       LEFT JOIN Clients scl ON sc.tiers_id = scl.id
	ORDER BY
	       _coa.account_number,
	       mov.transaction_date,
	       mov.transaction_id
END