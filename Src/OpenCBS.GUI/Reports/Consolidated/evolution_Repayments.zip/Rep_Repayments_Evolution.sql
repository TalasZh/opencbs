CREATE PROCEDURE [dbo].[Rep_Repayments_Evolution] 
	@pFrom DATETIME ,
	@pTo DATETIME ,
	@pPeriod NVARCHAR(2),
	@pBranch NVARCHAR(20)
AS
BEGIN

IF (@pPeriod = 'dd')
BEGIN
    SELECT CONVERT(NVARCHAR(10), load_date, 102) display_date,
           branch_name branch,
           SUM(principal) repayments
    FROM   Rep_Repayments_Data
    WHERE  load_date BETWEEN @pFrom AND @pTo
           AND (branch_name = @pBranch OR @pBranch = 'All')           
    GROUP BY
           load_date,
           branch_name
END
ELSE
BEGIN
    WITH repayments_data(load_date, branch_name, repayments) AS (
        SELECT load_date,
               branch_name,
               principal
        FROM   Rep_Repayments_Data rrd
        WHERE  load_date BETWEEN @pFrom AND @pTo
               AND (branch_name = @pBranch OR @pBranch = 'All')               
    )
    	
    SELECT rrd.load_date,
           CAST(DATEPART(YYYY, rrd.load_date)AS NVARCHAR) + ' - ' +
           CASE 
                WHEN @pPeriod = 'wk' THEN CASE 
                                               WHEN DATEPART(WK, rrd.load_date)
                                                    < 10 THEN 'W0' +
                                                    CAST(DATEPART(WK, rrd.load_date) AS NVARCHAR)
                                               ELSE 'W' + CAST(DATEPART(WK, rrd.load_date) AS NVARCHAR)
                                          END
                ELSE CASE 
                          WHEN DATEPART(m, rrd.load_date) 
                               < 10 THEN '0' + CAST(DATEPART(m, rrd.load_date) AS NVARCHAR)
                          ELSE CAST(DATEPART(m, rrd.load_date) AS NVARCHAR)
                     END
           END display_date,
           SUM(rrd.principal) repayments,
           rrd.branch_name branch
    FROM   Rep_Repayments_Data rrd
           INNER JOIN (
                    SELECT MAX(load_date) load_date,
                           branch_name
                    FROM   repayments_data
                    GROUP BY
                           DATEPART(YYYY, load_date),
                           CASE 
                                WHEN @pPeriod = 'wk' THEN DATEPART(WK, load_date)
                                ELSE DATEPART(M, load_date)
                           END,
                           branch_name
                ) g
                ON  rrd.load_date = g.load_date
                AND rrd.branch_name = g.branch_name
    GROUP BY
           rrd.load_date,
           rrd.branch_name
END
END