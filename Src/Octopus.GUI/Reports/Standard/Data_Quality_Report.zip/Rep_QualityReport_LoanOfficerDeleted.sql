create PROCEDURE Rep_QualityReport_LoanOfficerDeleted
AS BEGIN
SELECT credit.id, contract_code, users.[first_name] + ' ' + users.[last_name] as loan_officer, 
 dbo.[GetOLB](credit.id,GETDATE()) as olb
FROM
contracts INNER JOIN
credit ON credit.id = contracts.id INNER JOIN
users ON users.id = credit.[loanofficer_id]
WHERE [loanofficer_id] IN (SELECT id FROM users WHERE [deleted] = 1) and round(dbo.[GetOLB](credit.id,GETDATE()),2) >0
ORDER BY OLB
END