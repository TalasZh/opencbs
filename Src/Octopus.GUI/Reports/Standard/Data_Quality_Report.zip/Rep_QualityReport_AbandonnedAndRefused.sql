CREATE view AbandonnedAndRefused	
AS
SELECT	dbo.contracts.contract_code, 
		case when dbo.contracts.status=3 then 'Refused' else 'Abandonned' end as contract_status, 
		dbo.users.first_name+' '+dbo.users.last_name as LO_name, 
		dbo.districts.name as district_name, 
		case when  
		isnull((SELECT sum(contractevents.id) 
			FROM dbo.ContractEvents 
			WHERE event_type = 'LODE'
			and contract_id=contracts.id),0)=0 
		then 0 
		else 1 end as disbursed,
		dbo.credit.amount
FROM dbo.Contracts INNER JOIN 
	dbo.Credit ON contracts.id = credit.id INNER JOIN
	dbo.users ON users.id = credit.loanofficer_id INNER JOIN
	dbo.projects ON projects.id =contracts.project_id INNER JOIN
	dbo.tiers ON tiers.id = projects.tiers_id INNER JOIN
	dbo.districts ON districts.id = tiers.district_id 
	
WHERE dbo.contracts.status = 3 or dbo.contracts.status = 4
