CREATE PROCEDURE [dbo].[Rep_QualityReport_NoLoanOfficer]
AS
	BEGIN
		SELECT     dbo.Contracts.id, dbo.Contracts.contract_code, dbo.Persons.first_name + ' ' + dbo.Persons.last_name AS name
FROM         dbo.Contracts INNER JOIN
                      dbo.Credit ON dbo.Credit.id = dbo.Contracts.id INNER JOIN
                      dbo.Projects ON dbo.Contracts.project_id = dbo.Projects.id INNER JOIN
                      dbo.Tiers ON dbo.Tiers.id = dbo.Projects.tiers_id INNER JOIN
                      dbo.Persons ON dbo.Persons.id = dbo.Tiers.id
WHERE     (dbo.Tiers.client_type_code = 'I') AND (dbo.Credit.loanofficer_id NOT IN
                          (SELECT     id
                            FROM          dbo.Users))
UNION ALL
SELECT     dbo.Contracts.id, dbo.Contracts.contract_code, dbo.Groups.name
FROM         dbo.Contracts INNER JOIN
                      dbo.Credit ON dbo.Credit.id = dbo.Contracts.id INNER JOIN
                      dbo.Projects ON dbo.Contracts.project_id = dbo.Projects.id INNER JOIN
                      dbo.Tiers ON dbo.Tiers.id = dbo.Projects.tiers_id INNER JOIN
                      dbo.Groups ON dbo.Groups.id = dbo.Tiers.id
WHERE     (dbo.Tiers.client_type_code = 'G') AND (dbo.Credit.loanofficer_id NOT IN
                          (SELECT     id
                            FROM          dbo.Users))
END


