create PROCEDURE [dbo].[Rep_QualityReport_OLB] @branch_id INT
AS
BEGIN
SELECT  contracts.id, 
		SUM(principal) as principal_paid
INTO #olb_repayments
		FROM Contracts 
		left join contractevents on contractevents.contract_id = contracts.id
        left join RepaymentEvents ON ContractEvents.id = RepaymentEvents.id
		WHERE    (dbo.ContractEvents.is_deleted = 0) 
  			 AND (dbo.ContractEvents.event_date <= GETDATE())
group by contracts.id
SELECT  contracts.id,
		SUM(capital_repayment) as principal_repayment,
		SUM(paid_capital) as paid_principal
INTO #olb_installments
		FROM Contracts 
		left join Installments on installments.contract_id = contracts.id
group by contracts.id

SELECT 
contract_code,
round(al.olb,2) as olb_active_loans,
round((credit.amount - #olb_repayments.principal_paid),2) as olb_repayments,
round((credit.amount - #olb_installments.paid_principal),2) as olb_installments
FROM         dbo.activeloans(getdate(), @branch_id) al 
inner join dbo.Contracts on al.id = contracts.id 
inner join credit on contracts.id = credit.id
inner join  #olb_repayments ON #olb_repayments.id= contracts.id
inner join  #olb_installments on #olb_installments.id = contracts.id
WHERE   (round((credit.amount - #olb_repayments.principal_paid),2)<> round(al.olb,2))
		OR (round((credit.amount - #olb_installments.paid_principal),2)<>round(al.olb,2))
		OR  (round(#olb_repayments.principal_paid,2)<>round(#olb_installments.paid_principal,2))

END


