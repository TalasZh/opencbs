CREATE PROCEDURE [dbo].[Rep_QualityReport_WeirdContracts] @branch_id INT
AS BEGIN
SELECT    
dbo.Contracts.contract_code, 
dbo.Contracts.closed,
al.olb,
users.first_name + ' ' + users.last_name AS loan_officer, 
ISNULL(dbo.Groups.name, dbo.Persons.first_name + ' ' + dbo.Persons.last_name) AS client_name
FROM   dbo.activeloans(getdate(), @branch_id) al
INNER JOIN dbo.Contracts on al.id = contracts.id
INNER JOIN dbo.Credit ON dbo.Contracts.id = dbo.Credit.id 
INNER JOIN dbo.Users ON dbo.Credit.loanofficer_id = dbo.Users.id 
INNER JOIN dbo.Projects ON dbo.Contracts.project_id = dbo.Projects.id 
INNER JOIN dbo.Tiers ON dbo.Projects.tiers_id = dbo.Tiers.id 
LEFT OUTER JOIN dbo.Groups ON dbo.Tiers.id = dbo.Groups.id 
LEFT OUTER JOIN dbo.Persons ON dbo.Tiers.id = dbo.Persons.id
WHERE  (((al.olb > 0) AND (al.olb <= 5)) 
	OR  ((al.olb > 0) AND (contracts.closed = 1)) 
	OR  (al.olb < 0))
	AND credit.written_off=0
END


