CREATE PROCEDURE [dbo].[Rep_QualityReport_GroupMembersOld]
AS
	BEGIN
		SELECT     TOP (100) PERCENT dbo.Contracts.contract_code,
                          (SELECT     COUNT(person_id) AS Expr1
                            FROM          dbo.PersonGroupBelonging
                            WHERE      (group_id = dbo.Projects.tiers_id)) AS pCount
FROM         dbo.Contracts INNER JOIN
			 dbo.credit on contracts.id = credit.id inner join 
                      dbo.Projects ON dbo.Projects.id = dbo.Contracts.project_id INNER JOIN
                      dbo.Tiers ON dbo.Projects.tiers_id = dbo.Tiers.id
WHERE     (dbo.Tiers.client_type_code = 'G') AND
                          ((SELECT     COUNT(person_id) AS Expr1
                              FROM         dbo.PersonGroupBelonging AS PersonGroupBelonging_1
                              WHERE     (group_id = dbo.Projects.tiers_id)) = 0) AND
                          (((SELECT     SUM(capital_repayment - paid_capital) AS Expr1
                              FROM         dbo.Installments
                              WHERE     (contract_id = dbo.Contracts.id)) <= 0.02)
						 OR credit.written_off=1)
ORDER BY pCount
	END


