CREATE PROCEDURE [dbo].[Rep_QualityReport_NullLoanShareAmount]
AS
	BEGIN
		SELECT     dbo.Contracts.id, dbo.Contracts.contract_code, dbo.Groups.name AS group_name, 
                      dbo.Persons.first_name + ' ' + dbo.Persons.last_name AS client_name,
					 dbo.Users.first_name + ' ' + dbo.Users.last_name AS loan_officer, 
                      dbo.LoanShareAmounts.amount
FROM         dbo.Contracts INNER JOIN
                      dbo.Credit ON dbo.Credit.id = dbo.Contracts.id INNER JOIN
                      dbo.Projects ON dbo.Contracts.project_id = dbo.Projects.id INNER JOIN
                      dbo.Tiers ON dbo.Tiers.id = dbo.Projects.tiers_id INNER JOIN
                      dbo.Groups ON dbo.Groups.id = dbo.Tiers.id INNER JOIN
                      dbo.LoanShareAmounts ON dbo.LoanShareAmounts.group_id = dbo.Tiers.id INNER JOIN
                      dbo.Persons ON dbo.Persons.id = dbo.LoanShareAmounts.person_id INNER JOIN
					  dbo.PersonGroupBelonging ON PersonGroupBelonging.person_id = persons.id and persongroupbelonging.group_id =groups.id inner join
                      dbo.Users ON dbo.Users.id = dbo.Credit.loanofficer_id
WHERE     (dbo.PersonGroupBelonging.currently_in = 1) AND (dbo.LoanShareAmounts.amount = 0)
	END


