CREATE PROCEDURE [dbo].[Rep_QualityReport_SameContractCodes]
AS
	BEGIN
		SELECT     dbo.Contracts.contract_code, dbo.Persons.first_name + ' ' + dbo.Persons.last_name AS name, 
                      dbo.Users.first_name + ' ' + dbo.Users.last_name AS loan_officer
FROM         dbo.Contracts INNER JOIN
                      dbo.Credit ON dbo.Credit.id = dbo.Contracts.id INNER JOIN
                      dbo.Projects ON dbo.Contracts.project_id = dbo.Projects.id INNER JOIN
                      dbo.Tiers ON dbo.Tiers.id = dbo.Projects.tiers_id INNER JOIN
                      dbo.Persons ON dbo.Persons.id = dbo.Tiers.id INNER JOIN
                      dbo.Users ON dbo.Users.id = dbo.Credit.loanofficer_id
WHERE     (dbo.Tiers.client_type_code = 'I')
GROUP BY dbo.Contracts.contract_code, dbo.Persons.first_name + ' ' + dbo.Persons.last_name, 
dbo.Users.first_name + ' ' + dbo.Users.last_name
HAVING      (COUNT(dbo.Contracts.contract_code) > 1)
UNION ALL
SELECT     dbo.Contracts.contract_code, dbo.Groups.name, dbo.Users.first_name + ' ' + dbo.Users.last_name AS loan_officer
FROM         dbo.Contracts INNER JOIN
                      dbo.Credit ON dbo.Credit.id = dbo.Contracts.id INNER JOIN
                      dbo.Projects ON dbo.Contracts.project_id = dbo.Projects.id INNER JOIN
                      dbo.Tiers ON dbo.Tiers.id = dbo.Projects.tiers_id INNER JOIN
                      dbo.Groups ON dbo.Groups.id = dbo.Tiers.id INNER JOIN
                      dbo.Users ON dbo.Users.id = dbo.Credit.loanofficer_id
WHERE     (dbo.Tiers.client_type_code = 'G')
GROUP BY dbo.Contracts.contract_code, dbo.Groups.name, dbo.Users.first_name + ' ' + dbo.Users.last_name
HAVING      (COUNT(dbo.Contracts.contract_code) > 1)
END


