CREATE PROCEDURE [dbo].[Rep_ClientLoanStatistics] @endDate datetime,
@disbursed_in INT, @display_in INT, @branch_id INT
AS 
BEGIN        
    SELECT
    ScaleMin,
    ScaleMax,
    ac.id as client_id, 
    ac.contract_id, 
    ac.olb ,
    c1.contract_code AS Contract,
    dbo.Users.first_name + ' ' + dbo.Users.last_name AS loan_officer,
    dbo.Districts.name AS District,
    dbo.Credit.grace_period,
    dbo.Credit.amount * dbo.GetXR(pkg.currency_id, @display_in, @endDate) AS amount,
    dbo.Credit.nb_of_installment AS maturity,
    dbo.InstallmentTypes.nb_of_days,
    dbo.InstallmentTypes.nb_of_months,
    dbo.InstallmentTypes.name,
    dbo.Persons.sex,
    dbo.EconomicActivities.name AS domainName
    FROM
    dbo.LoanScale, 
    dbo.credit
    INNER JOIN dbo.installmentTypes ON dbo.Credit.installment_type = dbo.InstallmentTypes.id 
    INNER JOIN dbo.users on credit.loanofficer_id = users.id 
    INNER JOIN dbo.contracts as c1 on c1.id = credit.id 
    INNER JOIN dbo.projects on projects.id = c1.project_id 
    INNER JOIN dbo.tiers on tiers.id = projects.tiers_id 
    INNER JOIN dbo.districts on districts.id = tiers.district_id 
    INNER JOIN dbo.ActiveClients_MC(@endDate,@disbursed_in,@display_in, @branch_id) as ac on ac.contract_id = credit.id 
    INNER JOIN dbo.persons on persons.id = ac.id 
    INNER JOIN dbo.EconomicActivities ON dbo.Persons.activity_id = dbo.EconomicActivities.id
    LEFT JOIN dbo.Packages AS pkg ON pkg.id = dbo.Credit.package_id
    WHERE (Credit.amount >= LoanScale.ScaleMin AND Credit.amount <= LoanScale.ScaleMax)
    AND (pkg.currency_id = @disbursed_in OR 0 = @disbursed_in)
    AND tiers.branch_id = @branch_id
END
