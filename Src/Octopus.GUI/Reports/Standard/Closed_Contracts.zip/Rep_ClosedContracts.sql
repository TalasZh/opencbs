CREATE PROCEDURE Rep_ClosedContracts
	@beginDate DATETIME,
	@endDate DATETIME,
	@disbursed_in INT,
	@display_in INT,
	@branch_id INT
AS
BEGIN
	--DECLARE @beginDate     DATETIME = CAST(DATEADD(M, -1, GETDATE()) AS DATE),
	--        @endDate       DATETIME = CAST(GETDATE() AS DATE),
	--        @disbursed_in  INT = 0,
	--        @display_in    INT = 1,
	--        @branch_id     INT = 1
	
	SELECT co.contract_code,
	       pa.name,
	       cc.client_name,
	       cc.loan_officer,
	       cc.amount * dbo.GetXR(cc.currency_id, @display_in, cc.close_date) AS 
	       amount,
	       ce.event_date AS disb_date,
	       cc.close_date,
	       cc.currency
	FROM   ClosedContracts(@beginDate, @endDate, @branch_id) cc
	       INNER JOIN Contracts co
	            ON  co.id = cc.contract_id
	       INNER JOIN Credit cr
	            ON  cr.id = cc.contract_id
	       INNER JOIN Packages pa
	            ON  pa.id = cr.package_id
	       INNER JOIN ContractEvents ce
	            ON  co.id = ce.contract_id
	            AND ce.event_type = 'LODE'
	            AND ce.is_deleted = 0
	WHERE  (cc.currency_id = @disbursed_in OR 0 = @disbursed_in)
	ORDER BY
	       close_date,
	       loan_officer
END

