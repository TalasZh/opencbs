CREATE PROCEDURE [dbo].[Rep_Collateral_Report]
@endDate DATE
, @disbursed_in INT
, @display_in INT
, @branch_id INT

AS BEGIN

	IF OBJECT_ID('tempdb..#retval') IS NOT NULL
    DROP TABLE #retval

	CREATE TABLE #retval
	(
		contract_collateral_id INT
		, product_id INT
		, custom1 NVARCHAR(255)
		, custom2 NVARCHAR(255)
		, custom3 NVARCHAR(255)
		, custom4 NVARCHAR(255)
		, custom5 NVARCHAR(255)
		, custom6 NVARCHAR(255)
		, custom7 NVARCHAR(255)
	)
	
	DECLARE @product_id INT
	DECLARE @contract_collateral_id INT
	DECLARE @value NVARCHAR(255)
	DECLARE @old_contract_collateral_id INT
	DECLARE @i INT
	DECLARE @sql NVARCHAR(255)

	DECLARE cur CURSOR FOR
	SELECT cpv.contract_collateral_id
		, cpr.id AS product_id
		, (CASE WHEN 4 = cp.[type_id] THEN cpc.value ELSE cpv.value END) AS value
	FROM dbo.CollateralPropertyValues cpv
	INNER JOIN dbo.CollateralProperties cp ON cp.id = cpv.property_id
	INNER JOIN dbo.CollateralProducts cpr ON cpr.id = cp.product_id
	INNER JOIN dbo.CollateralsLinkContracts clc ON clc.id = cpv.contract_collateral_id
	LEFT JOIN 
	(
		SELECT ROW_NUMBER() OVER (PARTITION BY property_id ORDER BY property_id) AS id, property_id, value FROM dbo.CollateralPropertyCollections
	) cpc ON CONVERT(NVARCHAR(255), cpc.id) = cpv.value AND cp.id = cpc.property_id
	
	OPEN cur

	FETCH NEXT FROM cur INTO @contract_collateral_id, @product_id, @value
	SET @old_contract_collateral_id = 0
	SET @i = 1

	WHILE 0 = @@FETCH_STATUS
	BEGIN
		IF (@contract_collateral_id <> @old_contract_collateral_id)
		BEGIN
			SET @i = 1
			INSERT INTO #retval (contract_collateral_id, product_id)
			VALUES (@contract_collateral_id, @product_id)
		END
		
		IF (@i < 8)
		BEGIN
			SET @sql = 'UPDATE #retval SET custom' + CAST(@i AS NVARCHAR(5)) + '=N''' + REPLACE(@value, '''', '''''') + ''''
			SET @sql = @sql + ' WHERE product_id = ' + CAST(@product_id AS NVARCHAR(MAX))
			SET @sql = @sql + ' AND contract_collateral_id = ' + CAST(@contract_collateral_id AS NVARCHAR(MAX))
			EXEC sp_executesql @sql
		END
	
		SET @i = @i + 1
		SET @old_contract_collateral_id = @contract_collateral_id
		FETCH NEXT FROM cur INTO @contract_collateral_id, @product_id, @value
	END

	CLOSE cur
	DEALLOCATE cur
	
	SELECT co.contract_code
	, cl.name AS client_name
	, ISNULL(us.last_name, '') + ' ' + ISNULL(us.first_name, '') AS loan_officer
	, pkg.code AS loan_product_code
	, dis.name AS district
	, al.olb
	, al.amount
	, (SELECT name FROM CollateralProducts where id = r.product_id) AS collateral_type
	, r.custom1
	, r.custom2
	, r.custom3
	, r.custom4
	, r.custom5
	, r.custom6
	, r.custom7
	FROM ActiveLoans_MC(@endDate, @disbursed_in, @display_in ,@branch_id) al
	INNER JOIN Collaterals() col ON col.contract_id = al.id
	INNER JOIN Contracts co ON co.id = al.id
	INNER JOIN dbo.Credit cr ON cr.id = al.id
	LEFT JOIN dbo.Users us ON us.id = cr.loanofficer_id
	LEFT JOIN dbo.Packages pkg ON pkg.id = cr.package_id
	INNER JOIN dbo.Tiers ti ON ti.id = col.client_id
	LEFT JOIN dbo.Districts dis ON dis.id = ti.district_id
	LEFT JOIN dbo.Clients cl ON cl.id = ti.id
	LEFT JOIN #retval r ON r.contract_collateral_id = col.collateral_id
	
	DROP TABLE #retval
END