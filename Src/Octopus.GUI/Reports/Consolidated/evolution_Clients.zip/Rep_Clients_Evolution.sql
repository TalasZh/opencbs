CREATE PROCEDURE [dbo].[Rep_Clients_Evolution] @pFrom DATETIME , @pTo DATETIME , @pPeriod NVARCHAR(2) , @pBranch NVARCHAR(20)
AS
BEGIN
  SELECT MAX(dl.date) date,
    dl.display_date,
    dl.branch_name AS branch,
    SUM(dl.clients) AS number_of_clients    
  FROM(
    SELECT load_date as date,
          CASE @pPeriod
            WHEN 'm' THEN 
				CAST(DATEPART(YYYY,load_date)AS NVARCHAR)+' - '+
				CASE WHEN DATEPART(m,load_date) < 10 THEN '0'+CAST(DATEPART(m,load_date) AS NVARCHAR)
				ELSE CAST(DATEPART(m,load_date) AS NVARCHAR)
				END             
            WHEN 'wk' THEN 
				CASE WHEN DATEPART(wk, load_date)<10 THEN 'W0' + CAST(DATEPART(wk, load_date) AS NVARCHAR)
				ELSE 'W' + CAST(DATEPART(wk, load_date) AS NVARCHAR) 
				END            
            ELSE CONVERT(NVARCHAR(10), load_date, 101)
          END AS display_date, branch_name, clients
        FROM [dbo].[Rep_Active_Loans_Data]
        WHERE  load_date BETWEEN @pFrom AND @pTo AND (branch_name=@pBranch OR @pBranch='All')AND [break_down_type] = 'loan_officer'
	) AS dl --dates with labels			 
  GROUP BY dl.display_date,dl.branch_name
END