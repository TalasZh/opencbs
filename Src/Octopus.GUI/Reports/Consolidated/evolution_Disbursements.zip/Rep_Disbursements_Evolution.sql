CREATE PROCEDURE [dbo].[Rep_Disbursements_Evolution] 
	@pFrom DATETIME , 
	@pTo DATETIME , 
	@pPeriod NVARCHAR(2), 
	@pBranch NVARCHAR(20)
AS
BEGIN
	IF (@pPeriod = 'dd')
BEGIN
    SELECT CONVERT(NVARCHAR(10), load_date, 102) display_date,
           branch_name branch,
           SUM(amount) disbursements
    FROM   Rep_Disbursements_Data
    WHERE  load_date BETWEEN @pFrom AND @pTo
           AND (branch_name = @pBranch OR @pBranch = 'All')           
    GROUP BY
           load_date,
           branch_name
END
ELSE
BEGIN
    WITH disbursements_data(load_date, branch_name, disbursements) AS (
        SELECT load_date,
               branch_name,
               amount
        FROM   Rep_Disbursements_Data rdd
        WHERE  load_date BETWEEN @pFrom AND @pTo
               AND (branch_name = @pBranch OR @pBranch = 'All')               
    )
    	
    SELECT rdd.load_date,
           CAST(DATEPART(YYYY, rdd.load_date)AS NVARCHAR) + ' - ' +
           CASE 
                WHEN @pPeriod = 'wk' THEN CASE 
                                               WHEN DATEPART(WK, rdd.load_date)
                                                    < 10 THEN 'W0' +
                                                    CAST(DATEPART(WK, rdd.load_date) AS NVARCHAR)
                                               ELSE 'W' + CAST(DATEPART(WK, rdd.load_date) AS NVARCHAR)
                                          END
                ELSE CASE 
                          WHEN DATEPART(m, rdd.load_date) 
                               < 10 THEN '0' + CAST(DATEPART(m, rdd.load_date) AS NVARCHAR)
                          ELSE CAST(DATEPART(m, rdd.load_date) AS NVARCHAR)
                     END
           END display_date,
           SUM(rdd.disbursements) disbursements,
           rdd.branch_name branch
    FROM   disbursements_data rdd
           INNER JOIN (
                    SELECT MAX(load_date) load_date,
                           branch_name
                    FROM   disbursements_data
                    GROUP BY
                           DATEPART(YYYY, load_date),
                           CASE 
                                WHEN @pPeriod = 'wk' THEN DATEPART(WK, load_date)
                                ELSE DATEPART(M, load_date)
                           END,
                           branch_name
                ) g
                ON  rdd.load_date = g.load_date
                AND rdd.branch_name = g.branch_name
    GROUP BY
           rdd.load_date,
           rdd.branch_name
END
END