CREATE PROCEDURE Rep_Committee_Appraisal
				 @guarantee_id INT
AS BEGIN
SELECT Contracts.contract_code AS "contract_code",
	   Contracts.status AS "contract_status",
	   Contracts.credit_commitee_comment AS "guarantee_commitee_comment",
	   Contracts.credit_commitee_code AS "guarantee_commitee_code",
	   Contracts.credit_commitee_date AS "guarantee_commitee_date",
	   Guarantees.banque AS "guarantee",
	   Guarantees.amount_guaranted AS "amount_guaranted",
	   Guarantees.amount AS "guarantee_amount",
	   Guarantees.guarantee_fees AS "guarantee_fees",
	   ISNULL(Groups.name, ISNULL(Persons.first_name + ' ' + Persons.last_name, Corporates.name)) AS "client_name",
       Tiers.address AS "client_address",
	   Tiers.city AS "client_city",
       Districts.name AS "client_district",
	   GuaranteesPackages.name as "guarantee_product",
	   Users.first_name + ' ' + Users.last_name AS "loan_officer",
	   Currencies.name AS "currency"
FROM [dbo].[Contracts]
	 INNER JOIN [dbo].[Guarantees] ON Contracts.id = Guarantees.id
	 INNER JOIN [dbo].[GuaranteesPackages] ON Guarantees.guarantee_package_id = GuaranteesPackages.id
	 INNER JOIN [dbo].[Currencies] ON GuaranteesPackages.currency_id = Currencies.id
	 INNER JOIN [dbo].[Projects] ON  contracts.project_id = projects.id
	 INNER JOIN [dbo].[Tiers] ON Projects.tiers_id = Tiers.id
	 INNER JOIN [dbo].[Districts] ON Tiers.district_id = Districts.id
	 INNER JOIN [dbo].[Users] ON Guarantees	.loanofficer_id = Users.id
	 LEFT OUTER JOIN [dbo].[Persons] ON Tiers.id = Persons.id 
	 LEFT OUTER JOIN [dbo].[Groups] ON Tiers.id = Groups.id
	 LEFT OUTER JOIN [dbo].[Corporates] ON Tiers.id = Corporates.id
WHERE contracts.id = @guarantee_id
END