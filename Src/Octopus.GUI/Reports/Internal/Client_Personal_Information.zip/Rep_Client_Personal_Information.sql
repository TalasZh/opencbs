CREATE PROCEDURE Rep_Client_Personal_Information
	@person_id INT
	, @branch_id INT
AS BEGIN
	IF OBJECT_ID('tempdb..#thumbnails') IS NOT NULL
	BEGIN
	   DROP TABLE #thumbnails
	END

	CREATE TABLE #thumbnails	
	(
		num INT NOT NULL
		, thumbnail1 IMAGE NULL
		, thumbnail2 IMAGE NULL	
	)

	DECLARE @db_from NVARCHAR(MAX)
	DECLARE @db_to NVARCHAR(MAX)
	DECLARE @sql NVARCHAR(MAX)

	SELECT @db_from = DB_NAME()
	SET @db_to = @db_from + '_attachments'

	IF EXISTS (SELECT * FROM sys.databases WHERE name = @db_to)
	BEGIN
		SET @sql = 'INSERT INTO #thumbnails (num, thumbnail1)
		SELECT 1, thumbnail
		FROM ' + @db_to + '..Pictures
		WHERE id = ' + CAST(@person_id AS NVARCHAR(20)) + ' AND subid = 0'
		EXEC sp_executesql @sql	

		SET @sql = 'INSERT INTO #thumbnails (num, thumbnail2)
		SELECT 2, thumbnail
		FROM ' + @db_to + '..Pictures
		WHERE id = ' + CAST(@person_id AS NVARCHAR(20)) + ' AND subid = 1'
		EXEC sp_executesql @sql	
	END

	SELECT
	Pers.first_name
	,Pers.last_name
	,Pers.father_name
	,Pers.identification_data AS [id_number]
	,Pers.birth_date, Pers.sex AS [gender],
	ISNULL(Dis.name, '-') AS [district]
	,ISNULL(Tr.city, '-') AS [city]
	,ISNULL(Tr.address, '-') AS [address]
	,ISNULL(Dis2.name, '-') AS [sec_district]
	,ISNULL(Tr.secondary_city, '-') AS [sec_city]
	,ISNULL(Tr.secondary_address, '-') AS [sec_address]
	,ISNULL(Tr.personal_phone, '-') AS [phone]
	,ISNULL(Tr.secondary_home_phone, '-') AS [sec_phone], ISNULL(Tr.secondary_personal_phone, '-') AS [sec_pers_phone]
	, th1.thumbnail1 picture
	, th2.thumbnail2 picture2
	FROM Tiers AS Tr
	INNER JOIN Persons AS Pers ON Pers.id = Tr.id
	LEFT JOIN Districts AS Dis ON Dis.id = Tr.district_id
	LEFT JOIN Districts AS Dis2 ON Dis2.id = Tr.secondary_district_id
	LEFT JOIN #thumbnails th1 ON th1.num = 1
	LEFT JOIN #thumbnails th2 ON th2.num = 2
	WHERE Tr.id = @person_id
END