CREATE PROCEDURE Rep_Client_Personal_Information_Credit
	@person_id INT
	, @branch_id INT
AS BEGIN
	SELECT DISTINCT
	Cont.contract_code, 
	dbo.Statuses.Status_name AS [status],
	CASE WHEN LoSh.amount IS NOT NULL THEN LoSh.amount ELSE Cr.amount END AS [amount],
	ISNULL(AcLo.olb, '') AS [olb], 
	Cont.creation_date, Cont.start_date, Cont.close_date, 
	ISNULL(Gr.name, '-') AS [group_name], 
	CASE WHEN AcLo.late_days IS NOT NULL AND AcLo.late_days!=0 THEN total_late_days
	ELSE total_late_days END
	AS [total_late_days],
	CAST(CASE WHEN ContEv.count_atr > 0 THEN 1 ELSE 0 END AS BIT) AS has_atr
	FROM Contracts AS Cont
	INNER JOIN Credit As Cr On Cr.id = Cont.id
	INNER JOIN Projects AS Pr ON Cont.project_id = Pr.id
	INNER JOIN Tiers AS Tr ON Tr.id = Pr.tiers_id
	LEFT JOIN ActiveLoans(GETDATE(), @branch_id) AS AcLo ON AcLo.id = Cont.id
	LEFT JOIN LoanShareAmounts AS LoSh ON LoSh.contract_id = Cont.id
	LEFT JOIN Groups AS Gr On Gr.id = LoSh.group_id
	INNER JOIN 
	(
	SELECT     Installments.contract_id, 
	SUM (
		  CASE WHEN Installments.expected_date IS NULL AND Installments.paid_date IS NULL THEN 0
		  ELSE
			  CASE WHEN  Installments.paid_date IS NULL THEN 
				    CASE WHEN DATEDIFF(dd, Installments.expected_date, GETDATE())<0 THEN 0
					     ELSE DATEDIFF(dd, Installments.expected_date, GETDATE()) 
						 END
					ELSE CASE WHEN DATEDIFF(dd, Installments.expected_date, paid_date)<0 THEN 0 
						 ELSE DATEDIFF(dd, Installments.expected_date, paid_date)
					     END
					END
			  END
		)AS total_late_days
	FROM      dbo.Installments
	GROUP BY Installments.contract_id
	) AS Ins ON Ins.contract_id = Cont.id INNER JOIN
	dbo.Statuses ON Cont.status = dbo.Statuses.id
	LEFT JOIN
	(
	SELECT
	contract_id, COUNT(id) AS [count_atr]
	FROM ContractEvents AS ContEv
	WHERE ContEv.event_type = 'ATR' AND ContEv.is_deleted = 0
	GROUP BY contract_id
	) AS ContEv ON ContEv.contract_id = Cont.id
	WHERE (Tr.id = @person_id OR LoSh.person_id = @person_id)
END
